# Matloob Tax & Consulting

One combined app that serves:

- The public marketing site at `/` (home, services, fees, resources, about, contact)
- The secure client portal at `/portal` (React SPA with file exchange and messaging)
- The JSON API at `/api`

All from a single Node + Express server. Designed to deploy as one Render service at matloob-ea.com.

## Structure

```
marketing/        Static HTML/CSS/JS for the public site
client/           React source for the portal SPA (built with Vite to dist/public)
server/           Express API + static server
shared/           Drizzle schema shared between client and server
render.yaml       Render Blueprint — provisions the service, disk, and env vars
```

## Develop locally

```bash
npm install
npm run dev           # http://localhost:5000
```

Marketing pages live at the root, portal at `/portal/`, API at `/api/`.

## Build + run in production mode

```bash
npm run build
npm start
```

## Deploy

Follow `Deployment-Guide.pdf`.
