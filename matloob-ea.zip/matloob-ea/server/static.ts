import express from 'express';
import type { Express, Request, Response, NextFunction } from 'express';
import fs from "node:fs";
import path from "node:path";

export function serveStatic(app: Express) {
  // Portal SPA lives at /portal — built React app from Vite
  const portalPath = path.resolve(__dirname, "public");
  if (!fs.existsSync(portalPath)) {
    throw new Error(
      `Could not find the portal build directory: ${portalPath}, make sure to run 'npm run build' first`,
    );
  }

  // Marketing site lives at root — static HTML/CSS/JS
  // In production (dist/index.cjs) __dirname is dist/, so marketing is at ../marketing
  const marketingPath = path.resolve(__dirname, "..", "marketing");
  if (!fs.existsSync(marketingPath)) {
    throw new Error(
      `Could not find the marketing directory: ${marketingPath}`,
    );
  }

  // --- Marketing site (root and subpaths) ---
  // Serve static assets (CSS, JS, images, HTML) from marketing/
  app.use(
    express.static(marketingPath, {
      extensions: ["html"], // /about -> /about.html
      index: "index.html",
    }),
  );

  // Explicit route for /services (nested folder needs its index.html resolved)
  app.get("/services", (_req, res) => {
    res.sendFile(path.join(marketingPath, "services", "index.html"));
  });
  app.get("/services/", (_req, res) => {
    res.sendFile(path.join(marketingPath, "services", "index.html"));
  });

  // --- Portal SPA at /portal ---
  // Serve hashed assets (JS/CSS chunks emitted by Vite) under /portal/*
  app.use("/portal", express.static(portalPath, { index: false }));

  // Any /portal or /portal/anything-not-a-file -> portal index.html (SPA)
  app.get(/^\/portal(\/.*)?$/, (req: Request, res: Response, next: NextFunction) => {
    // If request is for a static file that exists under portalPath, serve it
    const requested = req.path.replace(/^\/portal/, "");
    const filePath = path.join(portalPath, requested);
    if (requested && fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
      return res.sendFile(filePath);
    }
    return res.sendFile(path.join(portalPath, "index.html"));
  });

  // --- 404 fallback for anything else that isn't marketing static ---
  // Only reached if no prior handler matched AND the file isn't in marketing/
  app.use((req: Request, res: Response) => {
    // Try a final fallback to marketing index for unknown paths? No — return 404 page
    const notFoundPath = path.join(marketingPath, "404.html");
    if (fs.existsSync(notFoundPath)) {
      return res.status(404).sendFile(notFoundPath);
    }
    return res.status(404).sendFile(path.join(marketingPath, "index.html"));
  });
}
